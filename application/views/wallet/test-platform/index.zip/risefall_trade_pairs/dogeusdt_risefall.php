<script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
<style type="text/css">
    table{
        overflow-x:auto;
    }

    .btn-group-vertical>.btn.active, .btn-group-vertical>.btn:active, .btn-group-vertical>.btn:focus, .btn-group>.btn.active, .btn-group>.btn:active, .btn-group>.btn:focus {
        z-index: 0;
    }

    /*.bootstrap-select.btn-group .dropdown-menu li a:hover {
         color: whitesmoke !important;
         background: #bf5279 !important;
     }*/

     .btn .dropdown-toggle .btn-light{
        color: whitesmoke !important;
        background: #bf5279 !important;
     }

     .nav .nav-tabs .nav-fill{
        
     }

    .nav-tabs .nav-item.show .nav-link, .nav-tabs .nav-link {
        background-color: rgba(0, 0, 0, .10);
    }

    .make_me_dark{
        background-color: rgba(0, 0, 0, .05);
    }
</style>

<!-- <div class="text-danger p-2" id="testNotes">
    <b>Testing Mode:</b>
    <br>
    USDT Won/lose wont be sent until testing mode is turned on.
    To reset available amount, go to home and redirect to this page again.
    <br><br>
    Other USDT Token Pair will be added once testing mode is completed
</div>
 -->

<div id="innerContainer">

    <div class="text-light p-1" style="background-color:#131722">

        <div class="p-2 text-light">
            <label>Select Token Pair: </label>
            <select id="token_pair_select" style="background-color:#131722!important;color: white;" class="p-2 form-control">
                <option>BTC/USDT</option>
                <option>ETH/USDT</option>
                <option>XRP/USDT</option>
                <option>BNB/USDT</option>
                <option selected>DOGE/USDT</option>
                <option>TRX/USDT</option>
            </select>

            <div id="changeContainer">
                <span class="h5" id="token_pair_value_container"></span>

                <small id="token_pair_value_percentage_container"></small>
                <small>24 Hour change</small>
            </div>
        </div>

        <div class="tradingview-widget-container">
          <div id="tradingview" style="height: 400px;"></div>
        </div>

        <div class="d-flex justify-content-center pt-1 mb-2 mt-2">
            <button class="btn btn-success col-md" id="buy_rise_btn">
                <img style="width:25px;" src="assets/imgs/icons/growth-graph.png">
                Buy Rise
            </button>

            <button class="btn btn-danger col-md ml-1" id="buy_fall_btn">
                <img style="width:25px;" src="assets/imgs/icons/graph.png">
                Buy Fall
            </button>
        </div>
    </div>
</div>

<div class="mt-2 make_me_dark"> 
    <ul class="nav nav-tabs nav-fill">
      <li class="nav-item">
        <a class="nav-link text-dark active" aria-current="page" data-toggle="tab" href="#history_tab_btn">History</a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-dark" data-toggle="tab" href="#instructions_tab_btn">Instructions</a>
      </li>
    </ul>

    <div class="tab-content">

        <div id="history_tab_btn" class="tab-pane active">
            <table style="font-size: 13px;width: 100%;" cellpadding="5">
                <thead>
                  <tr>
                    <th scope="col">Type</th>
                    <th scope="col">Resolve Time</th>
                    <th scope="col">Amount</th>
                    <th scope="col">Price/Resolved</th>
                    <!-- <th scope="col"></th> -->
                    <th scope="col">Status</th>
                  </tr>
                </thead>
                <tbody id="positions_closed_container">
                    <tr class="text-center text-danger" id="no_history_position_flag_container">
                      <td colspan="5"><b>No positions opened</b></td>
                    </tr>
                </tbody>
            </table>

            <div class="text-center">
                Showing 5 latest history<br>
                <!-- <button class="btn btn-link" id="viewMore_history_btn">View More</button> -->
            </div>
        </div>

        <div id="instructions_tab_btn" class="tab-pane fade p-2">
          <span>
              1. Select token value prediction.<br>
              2. Select Time limit of prediction.<br>
              3. Input amount to be staked.<br>
              4. Wait for time prediction.<br>
              5. Check history if won or lost.<br>
              <br>

              <!-- *Additional<br>
              If the prediction is right but the token staked was not sent please report it as an appeal and wait for our admins to review what happened to your trade transaction -->
          </span>

          <!-- <br> -->
          <!-- <br> -->

          <div class="h6">FAQ:</div>
          <span>
              <b>1. How are the token predicted value being computed?</b><br>
              Your value predicted will check the timestamp of that minute's CLOSED value(based on binance OHLC data)

              <br>

              <b>2. Are my staked tokens will be liquidated if i lost, how about if i won?</b><br>
              The staked amount will be doubled if you have predicted the right amount but if you lose all your staked USDT will be liquidated. It's a high risk high reward kind of predictions
          </span>
        </div>
    </div>
</div>

<script type="text/javascript">
    var tokenPriceBinanceLastPrice;
    var totalAmountPending = 0;
    var tokenPairArray = {
        'tokenPairID':'DOGEUSDT',
        'tokenPairDescription':'DOGE/USDT'
    };

    var pendingPositionChecker;
    var tokenPriceInterval;

    $('#token_pair_select').change(function(){
        var selectedPair = $(this).val();
        var location;

        if(selectedPair=='BTC/USDT'){
            location = 'btcusdt_risefall';
        }

        if(selectedPair=='ETH/USDT'){
            location = 'ethusdt_risefall';
        }

        if(selectedPair=='XRP/USDT'){
            location = 'xrpusdt_risefall';
        }

        if(selectedPair=='BNB/USDT'){
            location = 'bnbusdt_risefall';
        }

        if(selectedPair=='DOGE/USDT'){
            location = 'dogeusdt_risefall';
        }

        if(selectedPair=='TRX/USDT'){
            location = 'trxusdt_risefall';
        }

        clearInterval(tokenPriceInterval);
        clearInterval(pendingPositionChecker);

        $.when(closeNav()).then(function() {
            $('#topNavBar').toggle();
            $("#container").fadeOut(animtionSpeed, function() {
                $("#loadSpinner").fadeIn(animtionSpeed,function(){
                    $("#container").empty();
                    $("#container").append(ajaxLoadPage('quickLoadPage',{'pagename':'wallet/test-platform/risefall_trade_pairs/'+location}));

                    console.log('wallet/test-platform/risefall_trade_pairs/'+location);

                    setTimeout(function(){
                        $("#loadSpinner").fadeOut(animtionSpeed,function(){
                            $('#topNavBar').toggle();
                            $("#container").fadeIn(animtionSpeed);
                        });
                    }, 2000);
                    
                });
            });
        });
    });

    setTimeout(function() {
        new TradingView.widget({
            "autosize": true,
            "symbol": "BINANCE:"+tokenPairArray.tokenPairID,
            // "symbol": "BINANCE:BTCUSDT",
            "interval": "1",
            "timezone": Intl.DateTimeFormat().resolvedOptions().timeZone,
            "theme": "dark",
            "style": "1",
            "locale": "en",
            "toolbar_bg": "#f1f3f6",
            "enable_publishing": false,
            "save_image": false,
            "container_id": "tradingview",
            "loading_screen": {
                "backgroundColor": "#f1f3f6",
            },
        });

        //continous
            tokenPriceInterval = setInterval(function() {
                tokenPriceBinanceLastPrice = parseFloat(ajaxShortLinkNoParse("https://api.binance.com/api/v3/ticker/24hr?symbol="+tokenPairArray.tokenPairID).lastPrice).toFixed(4);
                var tokenPriceBinancePriceChangePercent = parseFloat(ajaxShortLinkNoParse("https://api.binance.com/api/v3/ticker/24hr?symbol="+tokenPairArray.tokenPairID).priceChangePercent).toFixed(4);
                var signContainer;

                if(tokenPriceBinancePriceChangePercent.includes("-")){
                    $("#changeContainer").removeClass('text-success');
                    $("#changeContainer").addClass('text-danger');
                    signContainer = "";

                }else{
                    $("#changeContainer").addClass('text-success');
                    $("#changeContainer").removeClass('text-danger');
                    signContainer = "+";
                }

                $("#token_pair_value_container").html(tokenPriceBinanceLastPrice);
                $("#token_pair_value_percentage_container").html(signContainer+tokenPriceBinancePriceChangePercent);
            }, 1000);

    }, 2000);

    //callBackEnd
        balanceUsdt = ajaxShortLink('test-platform/getTokenBalanceBySmartAddress',{
            // 'trc20Address':currentUser['trc20_wallet'],
            'contractaddress':'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t',
        })['balance'];

        reloadPositions();
    //callBackEnd

    //buy
        $("#buy_rise_btn").on("click", function(){

            bootbox.alert({
                message: ajaxLoadPage('quickLoadPage',{'pagename':'wallet/test-platform/risefall_trade_pairs/buyrise'}),
                size: 'large',
                centerVertical: true,
                closeButton: false
            });
            
        });

        $("#buy_fall_btn").on("click", function(){
            bootbox.alert({
                message: ajaxLoadPage('quickLoadPage',{'pagename':'wallet/test-platform/risefall_trade_pairs/buyfall'}),
                size: 'large',
                centerVertical: true,
                closeButton: false
            });
        });
    //buy

    function minusToAmountAvailable(amountToMinus){
        balanceUsdtInner = float2DecimalPoints($("#available_amount_container").text().split(' ')[0])
        amountToMinus = float2DecimalPoints(amountToMinus)
        // console.log(typeof balanceUsdtInner, balanceUsdtInner);
        // console.log(typeof amountToMinus, amountToMinus);

        var newAmountAvail = balanceUsdtInner-amountToMinus;

        // console.log(typeof newAmountAvail, newAmountAvail);

        $("#available_amount_container").html(newAmountAvail+" USDT");
    }

    function addToAmountAvailable(amountToAdd){
        balanceUsdtInner = float2DecimalPoints($("#available_amount_container").text().split(' ')[0])
        amountToAdd = float2DecimalPoints(amountToAdd)
        // console.log(typeof balanceUsdtInner, balanceUsdtInner);
        // console.log(typeof amountToMinus, amountToMinus);

        var newAmountAvail = balanceUsdtInner+amountToAdd;

        // console.log(typeof newAmountAvail, newAmountAvail);

        $("#available_amount_container").html(newAmountAvail+" USDT");
    }

    function cancelPosition(id,element,amount){
        var res = ajaxPostLink('userWallet/future/cancelRiseFallPosition',{
            'id':id
        });

        addToAmountAvailable(amount)

        $(element).parent('td').parent('tr').remove();

        if ($("#positions_container tr").length == 0) {
            $("#positions_container").append(
                '<tr class="text-center text-danger" id="no_position_flag_container">'+
                   '<td colspan="5"><b>No positions opened</b></td>'+
                '</tr>'
            ); 
        }

        $.toast({
            heading: '<h6>Success</h6>',
            text: 'Canceled Position',
            showHideTransition: 'slide',
            icon: 'success',
            position: 'bottom-center'
        })
    }

    function reloadPositions(){
        var timing = '';
        // closed

            $("#positions_closed_container").empty();

            var closedPositions = ajaxShortLink(
                "userWallet/future/getClosedRiseFallPositions",
                {
                    'userID':15,
                    'tradePair':tokenPairArray.tokenPairDescription,
                }
            );

            closedPositions = closedPositions.slice(0,5).reverse()

            if (closedPositions.length == 0) {
                $("#no_history_position_flag_container").append(
                    '<tr class="text-center text-danger" id="no_history_position_flag_container">'+
                       '<td colspan="5"><b>No positions opened</b></td>'+
                    '</tr>'
                ); 
            }else{
                for (var x = 0; x < closedPositions.length; x++) {
                    var statusClass;

                    if (closedPositions[x].income == 30) {
                        timing = '30/30'
                    }else if(closedPositions[x].income == 50){
                        timing = '60/50'
                    }else if(closedPositions[x].income == 70){
                        timing = '120/70'
                    }else if(closedPositions[x].income == 90){
                        timing = '180/90'
                    }

                    if (closedPositions[x].status == "WIN") {
                        statusClass = 'text-success'
                    }else{
                        statusClass = 'text-danger'
                    }

                    $("#positions_closed_container").prepend(
                        '<tr class="'+statusClass+'">'+
                            '<td class="">'+closedPositions[x].buyType.toUpperCase()+'</td>'+
                            '<td class="">'+closedPositions[x].timeStamp+'</td>'+
                            '<td class="text-center">'+closedPositions[x].amount+'</td>'+
                            '<td class="">'+parseFloat(closedPositions[x].currentPrice).toFixed(2)+'/'+parseFloat(closedPositions[x].resolvedPrice).toFixed(2)+'</td>'+
                            // '<td class="">'+parseFloat(closedPositions[x].resolvedPrice).toFixed(2)+'</td>'+
                            '<td class="">'+closedPositions[x].status+' </td>'+
                        '</tr>'
                    ); 
                } 
            } 
        // closed
    }

    window.onbeforeunload = function() {
        return "Dude, are you sure you want to leave? Think of the kittens!";
    }
</script>