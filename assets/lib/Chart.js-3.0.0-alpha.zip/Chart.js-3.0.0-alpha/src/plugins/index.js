import filler from './plugin.filler';
import legend from './plugin.legend';
import title from './plugin.title';
import tooltip from './plugin.tooltip';

export default {
	filler,
	legend,
	title,
	tooltip
};
